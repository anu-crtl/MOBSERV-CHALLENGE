package fr.eurecom.android.grocery_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
        //UI views
    private EditText emailEt,passwordEt;
    private TextView forgotPd,noAccountTv;
    private Button loginbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //initialize views
        emailEt=findViewById(R.id.emailEt);
        passwordEt=findViewById(R.id.passwordEt);
        forgotPd=findViewById(R.id.forgotPd);
        noAccountTv=findViewById(R.id.noAccountTv);
        loginbutton=findViewById(R.id.loginbutton);

        noAccountTv.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterUserAcitvity.class));
            }
            });
        forgotPd.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, ForgotPassword.class));
            }

            });

        }
        }

