package fr.eurecom.android.grocery_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class ForgotPassword extends AppCompatActivity {
    private ImageButton backbutton ;
    private EditText emailEt;
    private Button recoverbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        backbutton=findViewById(R.id.backbutton);
        emailEt=findViewById(R.id.emailEt);
        recoverbutton=findViewById(R.id.recoverbutton);

        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });
    }
}